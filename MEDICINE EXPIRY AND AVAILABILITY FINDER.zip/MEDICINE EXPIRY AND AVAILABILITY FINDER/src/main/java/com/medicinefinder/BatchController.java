package com.medicinefinder;

import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class BatchController {
    private final BatchRepository repository;
    public BatchController(BatchRepository repository){this.repository=repository;}

    @GetMapping("/batches")
    public List<MedicineBatch> batches(@RequestParam(required=false) String q){
        return q==null||q.isBlank()?repository.findAll():repository.findByMedicineNameContainingIgnoreCaseOrGenericNameContainingIgnoreCase(q,q);
    }
    @GetMapping("/batches/{id}") public MedicineBatch get(@PathVariable Long id){return repository.findById(id).orElseThrow();}
    @PostMapping("/batches") public MedicineBatch create(@RequestBody MedicineBatch batch){batch.setId(null);return repository.save(batch);}
    @PutMapping("/batches/{id}") public MedicineBatch update(@PathVariable Long id,@RequestBody MedicineBatch batch){
        if(!repository.existsById(id))throw new NoSuchElementException("Batch not found");batch.setId(id);return repository.save(batch);
    }
    @DeleteMapping("/batches/{id}") public void delete(@PathVariable Long id){repository.deleteById(id);}
    @GetMapping("/dashboard") public Map<String,Object> dashboard(){
        List<MedicineBatch> all=repository.findAll(); LocalDate today=LocalDate.now();
        List<MedicineBatch> expiring=all.stream().filter(b->b.getExpiryDate()!=null&&!b.getExpiryDate().isBefore(today)&&!b.getExpiryDate().isAfter(today.plusDays(90))).toList();
        List<MedicineBatch> low=all.stream().filter(b->b.getQuantity()<=b.getReorderLevel()).toList();
        Map<String,Object> out=new LinkedHashMap<>();out.put("totalBatches",all.size());out.put("totalUnits",all.stream().mapToInt(MedicineBatch::getQuantity).sum());out.put("expiringCount",expiring.size());out.put("lowStockCount",low.size());out.put("expiring",expiring);out.put("lowStock",low);return out;
    }
}
