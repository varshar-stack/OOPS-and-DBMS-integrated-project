package com.medicinefinder;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.time.LocalDate;
import java.util.List;

@Configuration
public class DataInitializer {
    @Bean CommandLineRunner seed(BatchRepository repository){return args->{
        if(repository.count()>0)return;
        repository.saveAll(List.of(
            batch("Amoxicillin 500mg","Amoxicillin","Antibiotic","AMX-24018","Green Cross Pharmacy","14 Park Street, Kolkata","+91 98765 43210",18,20,84.50,LocalDate.now().plusDays(24)),
            batch("Vitamin D3 1000 IU","Cholecalciferol","Vitamins","VD3-11802","Carewell Pharmacy","8 Lake View Road, Kolkata","+91 98765 10022",42,15,125.00,LocalDate.now().plusDays(210)),
            batch("Metformin 500mg","Metformin","Diabetes care","MET-24007","City Medico","27 Gariahat Road, Kolkata","+91 98300 44112",8,20,39.00,LocalDate.now().plusDays(365)),
            batch("Cetirizine 10mg","Cetirizine","Allergy","CTZ-25011","Green Cross Pharmacy","14 Park Street, Kolkata","+91 98765 43210",64,20,22.00,LocalDate.now().plusDays(420)),
            batch("Atorvastatin 10mg","Atorvastatin","Heart health","ATV-22109","WellSpring Chemists","3 Camac Street, Kolkata","+91 98311 00881",26,12,118.00,LocalDate.now().plusDays(58)),
            batch("Omeprazole 20mg","Omeprazole","Digestive health","OMP-25003","City Medico","27 Gariahat Road, Kolkata","+91 98300 44112",5,15,54.00,LocalDate.now().plusDays(300))
        ));
    };}
    private MedicineBatch batch(String name,String generic,String category,String code,String pharmacy,String address,String phone,int qty,int reorder,double price,LocalDate expiry){
        MedicineBatch b=new MedicineBatch();b.setMedicineName(name);b.setGenericName(generic);b.setCategory(category);b.setBatchNumber(code);b.setPharmacyName(pharmacy);b.setPharmacyAddress(address);b.setPhone(phone);b.setQuantity(qty);b.setReorderLevel(reorder);b.setPrice(price);b.setExpiryDate(expiry);return b;
    }
}
