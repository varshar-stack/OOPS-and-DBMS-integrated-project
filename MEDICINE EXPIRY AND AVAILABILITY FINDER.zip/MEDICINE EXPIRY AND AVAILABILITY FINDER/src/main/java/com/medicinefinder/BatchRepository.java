package com.medicinefinder;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BatchRepository extends JpaRepository<MedicineBatch, Long> {
    List<MedicineBatch> findByMedicineNameContainingIgnoreCaseOrGenericNameContainingIgnoreCase(String name, String generic);
}
