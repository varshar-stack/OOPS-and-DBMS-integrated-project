package com.medicinefinder;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name="medicine_batches", indexes={@Index(columnList="medicineName"), @Index(columnList="pharmacyName")})
public class MedicineBatch {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    private String medicineName;
    private String genericName;
    private String category;
    private String batchNumber;
    private String pharmacyName;
    private String pharmacyAddress;
    private String phone;
    private int quantity;
    private int reorderLevel;
    private double price;
    private LocalDate expiryDate;
    public MedicineBatch() {}
    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public String getMedicineName(){return medicineName;} public void setMedicineName(String v){medicineName=v;}
    public String getGenericName(){return genericName;} public void setGenericName(String v){genericName=v;}
    public String getCategory(){return category;} public void setCategory(String v){category=v;}
    public String getBatchNumber(){return batchNumber;} public void setBatchNumber(String v){batchNumber=v;}
    public String getPharmacyName(){return pharmacyName;} public void setPharmacyName(String v){pharmacyName=v;}
    public String getPharmacyAddress(){return pharmacyAddress;} public void setPharmacyAddress(String v){pharmacyAddress=v;}
    public String getPhone(){return phone;} public void setPhone(String v){phone=v;}
    public int getQuantity(){return quantity;} public void setQuantity(int v){quantity=v;}
    public int getReorderLevel(){return reorderLevel;} public void setReorderLevel(int v){reorderLevel=v;}
    public double getPrice(){return price;} public void setPrice(double v){price=v;}
    public LocalDate getExpiryDate(){return expiryDate;} public void setExpiryDate(LocalDate v){expiryDate=v;}
}
