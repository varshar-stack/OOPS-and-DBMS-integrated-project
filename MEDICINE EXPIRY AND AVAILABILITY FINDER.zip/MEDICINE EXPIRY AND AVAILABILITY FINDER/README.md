# Medicine Expiry and Availability Finder

A Spring Boot and MySQL web application for pharmacy inventory, batch expiry alerts, low-stock monitoring, and medicine availability search across registered pharmacies.

## Requirements

- Java 17 or newer
- Maven 3.8+
- MySQL 8+

## Run locally

1. Start MySQL. Optionally run `database/schema.sql` in MySQL Workbench to create the database and `medicine_batches` table. The application can also create them automatically through JPA. It connects to `localhost:3306` as `root` with an empty password by default.
2. From this folder, run `mvn spring-boot:run`.
3. Open [http://localhost:8080](http://localhost:8080).

Set `DB_URL`, `DB_USERNAME`, and `DB_PASSWORD` environment variables to use different MySQL connection details. On the first run, the app creates six example medicine batches. Remove those rows from the database before using real inventory.

The current Java model stores medicine, batch, and pharmacy details together in `medicine_batches`. Expiry and low-stock alerts are calculated from these rows when the dashboard loads; they are not stored in separate alert tables.

## Main features

- Dashboard with inventory totals, expiry watch, and reorder alerts.
- Batch level inventory with medicine name, generic name, pharmacy, quantity, reorder level, price, and expiry date.
- Automatic expiry classification for batches expiring within 90 days.
- Smart low stock alerts when quantity is at or below the batch reorder level.
- Multi-pharmacy search by medicine or generic name.
- Add and remove batches from the web interface.

## API

- `GET /api/dashboard` — counts and alerting batches
- `GET /api/batches?q=...` — list or search batches
- `POST /api/batches` — add a batch
- `PUT /api/batches/{id}` — update a batch
- `DELETE /api/batches/{id}` — remove a batch
