-- Medicine Expiry and Availability Finder
-- This schema matches the current Spring Boot MedicineBatch entity.
-- Run in MySQL Workbench, or use: mysql -u root -p < database/schema.sql

CREATE DATABASE IF NOT EXISTS medicine_finder
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE medicine_finder;

CREATE TABLE IF NOT EXISTS medicine_batches (
    id BIGINT NOT NULL AUTO_INCREMENT,
    medicine_name VARCHAR(255),
    generic_name VARCHAR(255),
    category VARCHAR(255),
    batch_number VARCHAR(255),
    pharmacy_name VARCHAR(255),
    pharmacy_address VARCHAR(255),
    phone VARCHAR(255),
    quantity INT NOT NULL DEFAULT 0,
    reorder_level INT NOT NULL DEFAULT 0,
    price DOUBLE NOT NULL DEFAULT 0,
    expiry_date DATE,
    PRIMARY KEY (id),
    KEY idx_medicine_batches_medicine_name (medicine_name),
    KEY idx_medicine_batches_pharmacy_name (pharmacy_name),
    KEY idx_medicine_batches_expiry_date (expiry_date)
) ENGINE=InnoDB;

-- The Java app inserts six example batches automatically when this table is empty.
